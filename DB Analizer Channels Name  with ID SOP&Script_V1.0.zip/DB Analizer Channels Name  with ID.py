import re
from openpyxl import Workbook # type: ignore

# 1. Wczytaj plik TXT
with open("channels.txt", "r", encoding="utf-8") as f:
    text = f.read()

# 2. Wyciągnij wszystkie pary display_name i channel_index
# Szukamy wartości w formacie: display_name="..." oraz channel_index="..."
display_names = re.findall(r'display_name="([^"]+)"', text)
channel_indexes = re.findall(r'channel_index="([^"]+)"', text)

# 3. Dopasuj długości list (na wypadek, gdyby były nierówne)
max_len = max(len(display_names), len(channel_indexes))
while len(display_names) < max_len:
    display_names.append("")
while len(channel_indexes) < max_len:
    channel_indexes.append("")

# 4. Utwórz nowy plik Excel
wb = Workbook()
ws = wb.active
ws.title = "Channels"

# Dodaj nagłówki
ws.append(["Display_name", "Channel_index"])

# 5. Zapisz dane do Excela
for name, index in zip(display_names, channel_indexes):
    ws.append([name, index])

# 6. Zapisz plik
wb.save("channels_output.xlsx")

print(f"Save  {len(display_names)} records to channels_output.xlsx")
